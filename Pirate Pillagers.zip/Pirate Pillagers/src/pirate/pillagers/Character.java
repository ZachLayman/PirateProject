package pirate.pillagers;

public class Character {
    int x;
    int y;
    int speed;
    
    public Character () {
        
    }
    
    public Character (int x, int y, int speed) {
        this.x = x;
        this.y = y;
        this.speed = speed;
    }
}
